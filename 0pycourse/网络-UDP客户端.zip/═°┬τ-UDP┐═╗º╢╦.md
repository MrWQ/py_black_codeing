## UDP客户端

Python编写的UDP客户端和TCP客户端相差不大。我们仅需要做两处简单的修改，将数据包以UDP的格式发出。

 

### 代码实现

```python

#!/usr/bin/python3
# -*- encoding: utf-8 -*-
# @Time     : 2020/11/20 14:30 
# @Author   : ordar
# @File     : udp_client.py  
# @Project  : pythonCrouse
# @Python   : 3.7.5
import socket

# 定义我们的目标
target_host = "127.0.0.1"
target_port = 80
# 目标应该用元组的格式
target = (target_host, target_port)

# 建立一个socket对象
client = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

# 发送一些数据
client.sendto("AABBCC".encode('utf-8'), target)

# 接受返回的数据,客户端接受数据需要指定缓存区最大长度,指定接收的大小 为1024字节
data, address = client.recvfrom(1024)

print(data)

```

### 说明

正如你看到的，在创建套接字对象时，我们将套接字的类型改为SOCK_DGRAM。之后我们调用sendto（)函数将数据传到你想发送的服务器上，因为UDP是一个无连接状态的传输协议，所以不需要在此之前调用connect（）函数。最后一步是调用recvfrom（）函数接收返回的UDP数据包。你将接收到回传的数据及远程主机的信息和端口号。

因为我们的目标127.0.0.1:80并不是udp服务端，所以运行udp客户端会报错。先不要着急，等下我们实现了udp服务端再来配合这个客户端来使用。