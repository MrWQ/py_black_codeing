## TCP客户端 

在渗透测试的过程中，我们经常会遇到需要创建一个TCP客户端来连接服务、发送垃圾数据、进行模糊测试或者进行其他任务的情况。如果你工作在一个独立的大型企业网络环境中，那么你不会拥有丰富的网络工具或者编译器，你甚至可能会在一个不具备基本的复制和粘贴功能或者失去互联网连接的环境下工作。在这种环境下，你需要迅速手动创建一个TCP客户端。多说无益，我们开始编写代码。下面是一个简单的TCP客户端。实现一个简单的HTTP请求客户端。

### 代码实现

首先我们切换操作机到win7x64

![](img/ff640306-5098-11eb-bb88-8cc6814bc10b.png)

我们打开桌面的pycharm并编写以下代码

```python
#!/usr/bin/python3
# -*- encoding: utf-8 -*-
# @Time     : 2020/11/20 14:08 
# @Author   : ordar
# @File     : tcp_client.py
# @Project  : pythonCrouse
# @Python   : 3.7.5
import socket

# 定义我们的目标
target_host = "www.baidu.com"
target_port = 80
# 目标应该用元组的格式
target = (target_host, target_port)

# 建立一个socket对象
client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# 建立连接
client.connect(target)

# 发送一些数据，这里我们发送一个GET请求,python3只接收btye流
client.send("GET / HTTP/1.1\r\n\r\n".encode('utf-8'))

# 接受返回的数据,客户端接受数据需要指定缓存区最大长度,指定接收的大小 为1024字节
respon = client.recv(1024)

print(respon)

```



### 说明

首先，我们建立一个包含AF_INET和SOCK_STREAM参数的socket对象，AF_INET参数说明我们将使用标准的IPv4地址或者主机名，SOCK_STREAM说明这将是一个TCP客户端。然后，我们将客户端连接到服务器，并发送一些数据。最后一步是接收返回的数据并将响应数据打印出来。这是一个最简单的TCP客户端，但也将是你最经常写的一段代码。

如果访问不了百度可访问拓扑中的joomla，将target_host改成"192.168.1.11"

![](img/7b605100-4376-11eb-b2d6-8cc6814bc10b.png)

