### python访问注册表-获取用户账户列表

 

#### 什么是注册表

Windows中使用的注册表是一种数据库，它采用“键，值”的形式保存硬件信息、软件信息、用户信息，以及行为控制所需的各种信息。为了控制注册表，Windows通过接口支持与CRUD（Create Read Update Delete)相关的所有功能。入侵系统的黑客可以通过接口操作注册表，尝试初始化用户密码、修改防火墙设置、DLL注入等多种攻击。注册表也保存着用户使用网络的信息，通过这些信息，黑客也可以获知用户的生活方式。

 

![img](img/3bdccf1e-48bf-11eb-bdb3-8cc6814bc10b.png)

注册表是保存硬件、软件、用户、操作系统与程序的一般信息和设置信息的数据库。以前使  用ini文件保存相关信息，但由于每个程序都对应一个ini文件，所以很难开展有效管理与维护。

为解决这一问题，系统工程师引入了具有数据库形态的注册表。Windows操作系统与程序会自动向注册表输入信息，并进行更新。当然，用户也可以使用regedit等工具修改注册表。为防止程序启动错误，用户只能修改注册表的部分内容。注册表错误会给系统造成严重影响，请尽量不要随意修改。

![img](img/486beb34-48bf-11eb-821f-8cc6814bc10b.png)

在Windows命令行窗口输入regedit命令，即可打开“注册表编辑器”，如上图所示。注册表大致由4部分组成，最左侧是键区域，最上层的键称为根键，其下层键称为子键。选择某个键，就会看到对应的键值，由数据类型与数据成对组成。注册表以“配置单元”（Hive)为单位进行逻辑管理，以文件形式进行备份。注册表以根键为中心划分“配置单元”，最终保存到以“配置单元”为单位管理的文件。根键及其作用如图表所示：

| 根键名称            | 根键作用                                                     |
| ------------------- | ------------------------------------------------------------ |
| HKEY—CLASSES—ROOT   | 该根键根据windows操作系统中所安装的应用程序的扩展名，来指定文件类型。 |
| HKEY—CURRENT—USER   | 该根键包含了本地工作站中存放的当前登录的用户信息，包括用户登录名和存放的口令（注意，这个密码在输入的时候是隐藏的。）用户登录windos操作系统的时候，其信息从HKEY USERS 中相应的项复制到HKEY—CURRENT—USER中。 |
| HKEY—LOCAIMACHINE   | 该根键存放本地计算机的硬件信息，该根键下的子关键字包含在SYSTEM.DAT中用来提供HKEY—LOCAL—MACHINE所需要的信息，或者在远程计算机中可访问的一组键盘中。该根键下的许多与System.ini中的设置项类似。 |
| HKEY-USERS          | 该根键保存了存放在本地计算机口令列表中的用户标识和密码列表。每个用户的预配置信息都存储在HKEY-USERS根键中。HKEY—USERS是远程计算机中访问的根键之一。 |
| HKEY—CURRENT—CONFIG | 该根键存放着当前用户桌面配置的数据、最后使用的文档列表和其他有关的当前用户的windows版本的安装信息等。 |

 

#### 代码实现

Python提供_winreg模块，用于访问注册表信息。_winreg模块像一座桥梁，借助它，可以在Python中使用Windows提供的注册表API，且方法非常简单。先将根键设置给变量，再调用ConnectRegistry（）函数，连接注册表句柄。OpenKey（）函数以字符串形式设置下层注册表名称，返回控制句柄。然后，通过EnumValue（）函数获取注册表值。处理完成后，使用CloseKey（）函数关闭句柄。

 

使用regedit程序打开注册表，然后在HKEY_LOCAL MACHINE部分查看SOFTWARE\Microsoft\Windows NT\CurrentVersion\ProfileList项目，子目录中存在用户账户SID项，从中可以看到每个项目的ProfilelmagePath变量。系统将根据用户账户名分配的目录列表保存到相应变量。

 

下面使用Python编写程序，用于自动访问用户账户列表。先设置前面提及的注册表子目录，添加一些程序代码即可提取我们感兴趣的系统中使用的用户账户列表。

 

```python
#!/usr/bin/python3
# -*- encoding: utf-8 -*-
# @Time     : 2020/12/24 11:18 
# @Author   : ordar
# @File     : read_reg.py  
# @Project  : dll_injection2.py
# @Python   : 2.7.1
import sys
from _winreg import *

# 1. 设置子健目录：用户账号信息的子健目录
varSubKey = r"SOFTWARE\Microsoft\Windows NT\CurrentVersion\ProfileList"
# 2. 获取根注册表句柄对象：使用_winreg模块提供的HKEY_LOCAL_MACHINE，设置要搜索的根键
varReg = ConnectRegistry(None, HKEY_LOCAL_MACHINE)
# 3. 使用OpenKey函数获取句柄对象，可以打开注册表项
varKey = OpenKey(varReg, varSubKey)
for i in range(1024):
    try:
        # 4. 使用EnumKey访问子健目录
        keyname = EnumKey(varKey, i)
        varSubKey2 = "%s\\%s" % (varSubKey, keyname)
        # 5. 获取最终要访问的键的句柄
        varKey2 = OpenKey(varReg, varSubKey2)
        try:
            for j in range(1024):
                # 6. 访问键中键值项，包含键值名、键值、数据类型
                n, v, t = EnumValue(varKey2, j)
                if n:
                    # 7. 匹配账户信息并输出
                    if("ProfileImagePath" in n and "Users" in v):
                        print(v)
                else:
                    break
        except:
            errMsg = "Exception Inner:", sys.exc_info()[0]
            # print(errMsg)
        CloseKey(varKey2)
    except:
        errMsg = "Exception Outter:", sys.exc_info()[0]
        # print(errMsg)
        break
# 8. 关闭句柄对象
CloseKey(varKey)
CloseKey(varReg)

```

#### 运行结果

 ![image](img/48cf203a-48bf-11eb-aef6-8cc6814bc10b.png)