## Windows系统令牌权限

  源自微软的解释，Windows系统的令牌是指：“一个包含进程或者线程上下文安全信息的对象”，一个令牌如何初始化和被赋予何种权限或特权决定了进程或者线程能执行哪些任务。开发者出于好意会给一个安全产品内嵌一个系统托盘程序，这会让没有相应权限的用户控制以驱动形式存在的Windows系统服务。开发者在进程中使用了原生的WindowsAPI函数AdjustTokenPrivileges，并毫无恶意地将SeLoadDriver权限赋予了系统托盘程序。而出乎开发者预料的是，如果你可以插入代码到系统托盘程序，你也同样能够加载或者卸载任何驱动，这表明你可以布置一个能进入系统内核模式的rootkit，也意味着系统权限攻防游戏的结束。

  请牢记，如果你不能将你的进程监视器以SYSTEM或管理员身份运行，那么你需要始终盯住那些你能够监控的进程，以便发现是否有可以为你所用的附加权限。用户运行的权限配置错误的进程是一个极好的获取SYSTEM权限或者以系统内核态运行代码的途径。表中列出了那些我经常查找的有意思的权限。可以使用命令“whoami /priv”查询用户权限。

| 权限名称          | 具体被赋予的访问权限                                         |
| ----------------- | ------------------------------------------------------------ |
| SeBackupPrivilege | 该权限使得用户进程可以备份文件和目录，读取任何文件而无须关注它的访问控制列表（ACL） |
| seDebugPrivilege  | 该权限使得用户进程可以调试其他进程。当然包括获取进程句柄以便将DLL或者代码插入到运行的进程中去 |
| SeLoadDriver      | 该权限使得用户进程可以加载或者卸载驱动                       |

 

![img](img/c07b0b94-48b6-11eb-b1bb-8cc6814bc10b.png)

### 代码实现

现在，我们已经基本了解了在Windows系统里，权限是什么，以及需要找寻哪些权限。下面我们将利用Python自动化地获取正在监控的那些进程上已经启用的权限。

我们在进程监视器代码里面新增一个函数get_process_privileges，用来获取进程权限。

然后将privileges ="N/A"改成privileges = get_process_privileges(pid)，这样就可以打印出权限了

```python
#!/usr/bin/python
# -*- encoding: utf-8 -*-
# @Time     : 12/14/2020 4:49 PM
# @Author   : ordar
# @File     : process_monitor_token.py
# @Project  : new_project
# @Python   : 3.7.5

import win32con
import win32api
import win32security
import wmi


def get_process_privileges(pid):
    try:
        # 获取目标进程句柄
        hwd_proc = win32api.OpenProcess(win32con.PROCESS_QUERY_INFORMATION, False, pid)
        # 打开该进程的令牌
        hwd_tok = win32security.OpenProcessToken(hwd_proc, win32con.TOKEN_QUERY)
        # 解析已启用权限的列表。
        # 返回当前进程的所有权限信息。该函数调用返回的是一列元组，每个元组的第一个成员是具体权限，第二个成员则用于描述该权限是否启用。
        privs = win32security.GetTokenInformation(hwd_tok, win32security.TokenPrivileges)

        # 迭代每个权限并输出其中已经启用的
        priv_list = ""
        for i in privs:
            # 检测权限是否启用
            if i[1] == 3:
                priv_list += '%s|' % win32security.LookupPrivilegeName(None, i[0])
    except:
        priv_list = 'N/A'
    return priv_list


def log_to_file(message):
    """
    记录信息到文件
    :param message: 信息
    :return:
    """
    with open('process_monitor_log.csv', 'a') as log_file:
        log_file.write('%s \r\n' % message)


# 创建日志文件头
log_to_file("Time,User,Executable,CommandLine,PID,Patent PID,Privileges")

# 初始化WMI接口
c = wmi.WMI()
# 创建进程监控器:监控进程创建事件
process_watcher = c.Win32_Process.watch_for("creation")


while True:
    try:
        # 收集需要的进程信息
        new_process = process_watcher()
        proc_owner = new_process.GetOwner()
        # print(proc_owner)
        proc_owner = "%s\\%s" % (proc_owner[0], proc_owner[2])
        cretae_date = new_process.CreationDate
        executable = new_process.ExecutablePath
        cmdline = new_process.CommandLine
        pid = new_process.ProcessID
        parent_pid = new_process.ParentProcessId
        privileges = get_process_privileges(pid)
        log_message = '%s,%s,%s,%s,%s,%s,%s\r\n' % (cretae_date,proc_owner,executable,cmdline,pid,parent_pid,privileges)
        print(log_message)
        log_to_file(log_message)

    except:
        pass

```

### 运行结果

![img](img/e0b44a36-48b6-11eb-8ecd-8cc6814bc10b.png)