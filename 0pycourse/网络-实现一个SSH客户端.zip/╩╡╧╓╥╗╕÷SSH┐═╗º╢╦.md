## 实现一个SSH客户端

使用我们编写的netcat工具接收和发送数据非常方便，但有时候需要通过加密流量来避免检测，这是更明智的选择。最常用的办法就是使用Secure Shell（SSH)发送流量。但万一目标环境中没有SSH客户端怎么办呢（比如Windows主机）

  当然，Windows下有很多非常好的SSH客户端，比如Putty。在Python的世界里，你可以使用原始套接字和一些加密函数创建自己的SSH客户端或者服务端，使用Paramiko库中的PyCrypto能够让你轻松使用SSH2协议。

  为了了解这个函数库的工作方式，我们将使用Paramiko创建一个连接，在SSH的Linux系统上运行命令，然后配置SSH服务端和客户端在远程的Windows主机上运行命令，最后参照BHNET工具命令行参数的代理选项，展示包含Paramiko的反向隧道演示脚本。让我们开始吧。

### 代码实现

首先，使用pip安装程序获取Paramiko：pip install paramiko

然后开始编码

 

```python
#!/usr/bin/python3
# -*- encoding: utf-8 -*-
# @Time     : 2020/11/24 10:54 
# @Author   : ordar
# @File     : ssh_client.py  
# @Project  : pythonCourse
# @Python   : 3.7.5
from paramiko.client import SSHClient, AutoAddPolicy


# ssh认证，认证通过返回ssh连接
def ssh_connect(host_ip, host_port, username, passwd):
    ssh_client = SSHClient()
    try:
        ssh_client.set_missing_host_key_policy(AutoAddPolicy())
        ssh_client.connect(host_ip, int(host_port), username=username, password=passwd)
    except Exception as e:
        print(e)
        exit(1)
    return ssh_client


# 通过ssh连接执行命令
def ssh_command(ssh_client, cmd):
    try:
        stdin, stdout, stderr = ssh_client.exec_command(cmd)
        print(stdout.read().decode())
    except Exception as e:
        print(e)


if __name__ == '__main__':
    ssh_client = ssh_connect("192.168.1.16", 22, "root", "cyberrange")
    while True:
        cmd = input("<ssh command #>")
        if cmd == 'exit':
            ssh_client.close()
            exit(0)
        ssh_command(ssh_client, cmd)


```

 

### 运行结果

如果一切正常，linux服务器开启了ssh服务，并且账号密码正确，那么，运行结果应该类似这个截图：

![img](img/fd8248f8-437b-11eb-b13c-8cc6814bc10b.png)

 

