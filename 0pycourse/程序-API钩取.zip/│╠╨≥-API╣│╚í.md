## API钩取

API钩取技术利用了操作系统提供的调试进程。首先使用调试器，在应用程序特定的命令位置设置断点，注册特定方法以便执行。应用程序运行过程中，遇到断点就会执行之前注册的方法（回调方法），黑客只要在回调方法中植入黑客攻击代码即可执行相应动作。比如，向记事本（notepad)进程的WriteFile（)设置断点，用户点击保存菜单时就会调用并执行回调方法。如果黑客在回调方法中插入修改字符的代码，那么将导致最终保存的文本内容与用户输入的内容不一致。

![img](img/4fe9bd88-48bb-11eb-920c-8cc6814bc10b.png)

 

### Ctypes基本知识

- 加载DLL

  ctypes 支持多种调用约定（Calling Convention)。

ctypes 支持cdll、windll、oldell 调用约定。cd 支持cdecl调用约定，windll支持stdcall调用约定，oldell支持与windll相同的调用约定，但不同之处在于，其返回值假定为HRESULT。

windll.kernel32, windll.user32

- 调用Win32API

在DLL名称后指出要调用的函数名。

windll.user32.SetWindowsHookExA

也可以指定调用API时传递参数的数据类型。

printf = libc.printf 

printf.argtypes = [c_char p, c_char_p, c_int, c_double] 

printf("String '%s', Int %d, Double %f\n", "Hi", 10, 2.2)

还可以指定函数的返回值格式。

libc.strchr.restype = c_char_p

- 数据类型

通过ctypes模块提供的数据类型，Python可以使用C语言中的数据类型。比如使用C语言中的整型，可以如下使用ctypes实现。

i = c_int(42) 

print(i.value())

也可以声明用于保存地址的指针类型并使用。

PI = POINTER(c_int)

- 指针的传递

通过函数的参数，可以传递指针（值的地址）。

f = c_float() 

s = create_string_buffer('\000' * 32) 

windll.msvcrt.sscanf("1 3.14 Hello", "%f %s", byref(f), s)

- 回调函数

声明并传递回调函数，以便特定事件发生时进行调用。

def py_cmp_func(a,b)

​    print "py_cmp_func"

​    return 0

CMPFUNC = CFUNCTYPE(c_int,POINTER(c_int),POINTER(c_int))

cmp_func = CMPFUNC(py_cmp_func)

widll.msvcrt.qsort(ia, len(ia), sizeof(c_int), cmp_func)

- 结构体

继承Structure类，声明结构体类

class POINT(Structure):

_fields_ = [("x", c_int),("y", c_int)]

point = POINT(10, 20)

调用Win32API时，通常都需要传递参数。若将Python中使用的数据原样传递给Win32API，后者将无法正常识别数据，也就无法执行约定的动作。为了解决这一问题，ctypes 提供类型转换功能。类型转换是指，将Python数据类型转换为可以在Win32API中使用的数据类型。

 比如，调用sscanf（）函数时，参数必须是float类型的指针，使用ctypes提供的c_float 进行类型转换，可以保证函数得到正确调用。

 

| **ctypes**类型 | **C**类型                              | **Python**类型             |
| -------------- | -------------------------------------- | -------------------------- |
| c_char         | char                                   | 1-character string         |
| c_wchar        | wchar_t                                | 1-character unicode string |
| c_byte         | char                                   | int/long                   |
| c_ubyte        | unsigned char                          | int/long                   |
| c_short        | short                                  | int/long                   |
| c_ushort       | unsigned short                         | intlong                    |
| c_int          | int                                    | int/long                   |
| c_uint         | unsigned int                           | int/long                   |
| c_long         | long                                   | int/long                   |
| c_ulong        | unsigned long                          | int/long                   |
| c_longlong     | _int64或long long                      | int/long                   |
| c_ulonglong    | unsigned__int64 或  unsigned long long | int/long                   |
| c_float        | float                                  | float                      |
| c_double       | double                                 | float                      |
| c_char_p       | char * (NUL terminated)                | string 或 None             |
| c_wchar_p      | wchar_t * (NUL terminated)             | unicode 或 None            |
| c_void_p       | void *                                 | int/long 或 None           |

  

### 调试器概念

调试器可以暂时停止进程的行为动作，它是一种中断子程序。调试器执行完毕后，进程继续执行指定逻辑。调试器中，在需要调试的命令处设置断点，并不断监视事件发生。操作系统处理命令时，若发现断点，则调用指定的回调函数。

![img](img/acb63c78-48bb-11eb-9bb5-8cc6814bc10b.png)

使用调试器进行黑客攻击时，一般都会将黑客攻击脚本放入回调函数。其中，最具代表性的是APl钩取技术。程序调用保存数据的函数时，修改内存中的值即可对文件中保存的数据进行操作。

  

### API钩取过程

![img](img/c6aa933e-48bb-11eb-be84-8cc6814bc10b.png)

  1、2、3、4、5、7由程序员使用pydbg模块直接实现。6、8由操作系统负责，依据程序员注册的信息执行操作。

  ①获取PID：运行中的进程都有唯一的ID，它是操作系统分配给进程的识别码。通过Win32API可以获取所要调试进程的PID。

  ②获取命令地址：访问映射到相应进程地址空间中所有模块的列表，获取要设置断点的函数地址。

  ③设置断点：将命令代码的前2字节修改为CC，设置断点。调试器将原来的命令代码保存到其内部维护的断点列表，以确保能够返回原来的处理进程。

  ④注册回调函数：设置有断点的命令代码执行时，触发调试事件。操作系统产生中断，执行中断子程序。中断子程序就是程序员注册的回调函数。

  ⑤等待调试事件：使用Win32API等待调试事件发生。等待调用回调函数。

  ⑥发生调试事件：被调试进程运行过程中遇到断点时，触发中断。

  ⑦执行回调函数：发生中断时，执行中断子程序。事先注册的回调函数就是中断子程序。此时，将黑客攻击代码写入回调函数，即可执行想要的操作。

⑧进程恢复：回调函数执行完毕后，恢复正常的进程执行流程。

 

  Windows操作系统支持分步调用Win32API，如前所述，既可以使用ctypes模块，也可以使用pydbg模块。使用pydbg模块能够简化复杂的调用流程。通过ctypes调用DLL，可以使用C语言的数据类型。此外，通过ctypes，可以使用纯Python代码编写扩展模块。但通过ctypes 直接使用Windows DLL时，必须对Windows函数具备足够了解，掌握大量相关知识。并且，还要声明函数调用时所需的结构体与共用体（Union)，编写实现回调函数等。因此，与其直接使用ctypes，还不如安装已经开发的Python模块。pydbg模块是开源的Python 调试器，广泛应用于应用程序黑客攻击与逆向工程。

### Pydbg安装

网上很多教程，都不太好用，这里介绍一个最简单的方法。亲测WinXP、Win7、Win10均可安装成功。

1. 下载32位的python2.7

![img](img/de4c41e2-48bb-11eb-882d-8cc6814bc10b.png)

2. 安装完python之后设置环境变量。

我的python安装目录是C:\Python27，所以在系统变量Path里面添加

; C:\Python27\Scripts; C:\Python27

不要忘记分号。

![img](img/f2846ff0-48bb-11eb-bd46-8cc6814bc10b.png) ![img](img/033d5752-48bc-11eb-9af3-8cc6814bc10b.png)

3. 一步安装pydbg、pydasm

这个东西这么难装，所以有大神就弄了个一键安装的方法。

https://github.com/reider-roque/pydbg-pydasm-paimei

介绍：

该软件包的目的是为了便于在Windows机器上安装pydbg和pydasm Python模块。

该软件包为Windows x86 / x64的Python 2.6 / 2.7提供预编译的pydasm.pyd二进制文件。

将所有三个软件包（paimei，pydasm，pydbg）合并为一个，并对setup.py文件进行相应的编辑。

安装：

下载pydbg-pydasm-paimei.zip解压，进入pydbg-pydasm-paimei目录并运行python setup.py install

![img](img/1c79c582-48bc-11eb-8576-8cc6814bc10b.png)

导入一下测试，没有报错

![img](img/284892cc-48bc-11eb-b5b9-8cc6814bc10b.png)

Win7成功截图

![img](img/376be51e-48bc-11eb-8d4f-8cc6814bc10b.png)

### 代码实现

下面编写程序，钩取将数据保存到记事本的函数，将保存内容修改为程序员指定的内容。点击保存按钮时，将记事本中的love修改为Hate，然后创建记事本文件。虽然打开的记事本显示的love，但记事本保存文件中保存的却是hate。

![img](img/4748ff76-48bc-11eb-b11e-8cc6814bc10b.png)

 

我们切换操作机到win7x32，使用32位的win7操作系统，然后编写以下代码

![img](img/89197506-5099-11eb-9006-8cc6814bc10b.png)



**代码实现：**

```python
import utils, sys
from pydbg import *
from pydbg.defines import *

"""
BOOL WINAPI WriteFile( 
    _InHANDLE hFile, 
    _InLPCVOID 1pBuffer, 
    _InDWORD nNumberofBytesToWrite, 
    _out_optLPDWORD 1pNumberofBytesWritten, 
    _Inout_opt_LPOVERLAPPED 1pOverlapped 
）;
"""
dbg = pydbg()
isProcess = False
orgPattern = "love"
repPattern = "hate"
processName = "notepad.exe"

"""1.声明回调函数：声明回调函数，发生调试事件时调用。该函数内部含有钩取代码。"""
def replacestring(dbg, args):
    """2.读取内存值：从指定地址读取指定长度的内存地址，并返回其中值。
    内存中保存的值被记录到文件。（kernel32.ReadProcessMemory)"""
    buffer = dbg.read_process_memory(args[1], args[2])

    """3.在内存值中检查模式：在内存值中检查是否有想修改的模式。"""
    if orgPattern in buffer:
        print("[APTHoOking] Before: %s" % buffer)
        """4.修改值：若搜到想要的模式，则将其修改为黑客指定的值。"""
        buffer = buffer.replace(orgPattern, repPattern)
        """5.写内存：将修改值保存到内存。这是黑客希望在回调函数中执行的操作。
        将love修改为hate，并保存到内存。（kernel32.WriteProcessMemory)"""
        replace = dbg.write_process_memory(args[1], buffer)
        print("[APIHooking] After: %s" % dbg.read_process_memory(args[1], args[2]))
    return DBG_CONTINUE

"""6.获取进程D列表：获取Windows操作系统运行的所有进程ID列表。
（kemel32.CreateToolhelp32Snapshot)"""
for (pid, name) in dbg.enumerate_processes():
    if name.lower() == processName:
        isProcess = True
        hooks = utils.hook_container()
        """7.获取进程句柄：获取用于操纵进程资源的句柄，保存到类的内部。进程需要的动作通过句柄得到支持。
        （kermel32.OpenProcess、kernel32.DebugActiveProcess)"""
        dbg.attach(pid)
        print("Saces a process handle in self.h_process of pid[%d]" % pid)

        """8.获取要设置断点的函数地址：使用句柄访问进程的内存值。查找目标Win32API，返回相应地址。"""
        hookAddress = dbg.func_resolve_debuggee("kernel32.dll", "WriteFile")

        if hookAddress:
            """9.设置断点：向目标函数设置断点，注册回调函数，发生调试事件时调用。"""
            hooks.add(dbg, hookAddress, 5, replacestring, None)
            print("sets a breakpoint at the designated address: 0x%08x" % hookAddress)
            break
        else:
            print("Error:couldnot resolve hook address")
            sys.exit(-1)

if isProcess:
    print("waiting for occurring debugger event")
    """10.启动调试：无限循环状态下，等待调试事件发生。调试事件发生时，调用回调函数。"""
    dbg.run()
else:
    print("Error:There in no process [%s]" % processName)
    sys.exit(-1)

```

### 运行结果

运行环境：32位操作系统，如果无特殊说明，32位和64位均可

我们切换操作机到win7x32，使用32位的win7操作系统

![img](img/89197506-5099-11eb-9006-8cc6814bc10b.png)

这里截图使用的是vscode，我们可以继续使用pycharm编写代码，也可以尝试使用下vscode。

**Win7的32位系统运行截图：**

![img](img/89f5f3dc-48bc-11eb-b61e-8cc6814bc10b.png)

新建一个文件然后用记事本打开，通过tasklist命令查看到notepad的进程pid是3580。

程序运行后：可以看到程序成功获取到notepad进程的pid（3580）和内存地址0x761611cc。然后将“I love you”替换成了” I hate you”。

这里重新打开这个文件之后发现内容确实改变了。

![img](img/97395622-48bc-11eb-b137-8cc6814bc10b.png)

![img](img/b8e07a76-48bc-11eb-af08-8cc6814bc10b.png)

**Win7的64位系统运行会报错：**

![img](img/c84ed592-48bc-11eb-b071-8cc6814bc10b.png)