## 实现一个TCP代理

  有很多理由让你的工具箱中保留一个TCP代理，它不仅可以将流量从一个主机转发给另一个主机，而且可以评估基于网络的软件。在企业级环境下进行渗透测试时，你会经常遇到无法使用Wireshark的情况，无法在Windows系统上加载驱动嗅探本地流量，分段的网络也阻拦你使用工具直接嗅探目标主机。

 

### TCP服务端-接受请求

```python
import sys
import socket
import threading
 
 
 # 监听函数，接受本地请求 
 def server_loop(local_host, local_port, remote_host, remote_port, receive_first):
   server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
   try:
     server.bind((local_host, local_port))
   except:
     print("Failed to listen on {}:{}".format(local_host, str(local_port)))
     sys.exit(0)
   print("Listen on {}:{}".format(local_host, str(local_port)))
   server.listen(5)
 
   while True:
     client_socket, addr = server.accept()
     # 启动线程处理请求
     client_thread = threading.Thread(target=proxy_handler, args=(client_socket, remote_host, remote_port, receive_first))
     client_thread.start()
 
 
 def proxy_handler():
   pass
 
 
 if __name__ == '__main__':
   if len(sys.argv[1:]) != 5:
     print("Usage: tcp_proxy.py [local_host] [local_port] [remote_host] [remote_port] [receive_first]")
     print("Example: tcp_proxy.py 127.0.0.1 9999 192.168.1.2 80 True")
     sys.exit(0)
 
   # 设置本地监听参数
   local_host = sys.argv[1]
   local_port = int(sys.argv[2])
 
   # 设置远程目标
   remote_host = sys.argv[3]
   remote_port = int(sys.argv[4])
 
   # 告诉代理在发送给远程主机之前连接和接受数据
   receive_first = sys.argv[5]
   if "true" in receive_first.lower():
     receive_first = True
   else:
     receive_first = False
 
   server_loop(local_host, local_port, remote_host, remote_port, receive_first)
```

这里不在单独实现一个main函数了，直接用python特性的if __name__ == '__main__':来实现主要的脚本开始逻辑。

 

### 转储函数-记录流量

```python
def hexdump(src):
   # 此处转储流量，比如保存流量到文件
   with open('a.txt', 'a') as f:
     f.write(src.decode('utf-8') + '\n')
   return src
 
```

可以对流量进行处理，比如保存流量到本地，或者对请求和响应都需要处理的情况也可以写到这里。因为这个函数请求和响应都需要使用。

### 数据接收函数

```python
# 数据接收函数，从tcp连接中接收数据。因为有多个地方要从tcp连接中接收数据，所以封装一个函数来处理。
 def received_from(connection):
   buffer = b""
   # 设置10的超时
   connection.settimeout(10)
   try:
     while True:
       data = connection.recv(4096)
       if not data:
         break
       buffer += data
   except:
     pass
   return buffer
```

 

 

### TCP服务端-子线程-代理的主要逻辑

 

```python

def proxy_handler(client_socket, remote_host, remote_port, receive_first):
   remote_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
   remote_socket.connect((remote_host, remote_port))
 
   # 如果必要，先从远程主机获取数据
   if receive_first:
     remote_buffer = received_from(remote_socket)
     print(hexdump(remote_buffer))
 
     # 发送给响应处理，修改包
     remote_buffer = response_handler(remote_buffer)
     # 如果有数据，发送给本地客户端
     if remote_buffer:
       print("[<==] Sending {} bytes to localhost.".format(str(len(remote_buffer))))
       client_socket.send(remote_buffer)
 
   # 从本地循环读取数据，然后发送给远程主机和本地主机
   while True:
     local_buffer = received_from(client_socket)
     if local_buffer:
       print("[==>] Received {} bytes from localhost.".format(str(len(local_buffer))))
       print(hexdump(local_buffer))  # 这个是修改前的请求
       local_buffer = request_handler(local_buffer)
       print(hexdump(local_buffer))  # 这个是修改后的请求
       remote_socket.send(local_buffer)
       print("[==>] Send to remote.")
 
     remote_buffer = received_from(remote_socket)
     if remote_buffer:
       print("[<==] Received {} bytes from remote.".format(str(len(remote_buffer))))
       print(hexdump(remote_buffer))  # 这个是修改前的请求
       remote_buffer = response_handler(remote_buffer)
       print(hexdump(remote_buffer))  # 这个是修改后的请求
       client_socket.send(remote_buffer)
       print("[<==] Send to localhost.")
 
     # 如果两边都没有数据，关闭连接
     if not local_buffer and remote_buffer:
       client_socket.close()
       remote_socket.close()
       print("[*] No more data.closing connections")
       break
```

 

这个函数包含了代理的主体逻辑。首先，我们检查并确保在启动主循环之前，不向建立连接的远程主机主动发送数据。一些作为服务的进程可能会做这样的事情（例如FTP服务器一般会首先发送旗标）。然后，我们使用receive_from函数，我们在与接收方和发送方的通信中都将用到这个函数；它使用套接字对象实现数据的接收。然后我们转储数据包的负载，查看里面是否有感兴趣的内容。下一步，我们将接收的数据提交给response_handler函数。在函数中，我们可以修改数据包的内容，进行模糊测试任务，检测认证问题，或者其他任何你想做的事情。这里还有一个类似的request_handler函数可以将输出的流量进行修改。最后一步是将接收的缓存发送到本地客户端。

  剩下的代码非常简单：我们持续从本地读取数据、处理、发送到远程主机、从远程读取数据、处理、发送回本地主机，直到所有数据都处理完毕。

### 修改请求



```python
# 对目标是远程主机的请求进行修改
 def request_handler(buffer):
   # 执行修改
   buffer = buffer.decode('utf-8').replace("GET", "HEAD").encode('utf-8')
   return buffer

 
```

这里我们简单的将HTTP协议的GET请求改变为HEAD请求

### 修改响应

```python
# 对目标是本地主机的响应进行修改
 def response_handler(buffer):
   # 执行修改
   return buffer
```

 

### 代码实现和说明

 

```python
#!/usr/bin/python3
 # -*- encoding: utf-8 -*-
 # @Time   : 2020/11/23 17:00 
 # @Author  : ordar
 # @File   : tcp_proxy.py 
 # @Project : pythonCourse
 # @Python  : 3.7.5
 import sys
 import socket
 import threading
 
 
 # 监听函数，接收本地请求
 def server_loop(local_host, local_port, remote_host, remote_port, receive_first):
   server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
   try:
     server.bind((local_host, local_port))
   except:
     print("Failed to listen on {}:{}".format(local_host, str(local_port)))
     sys.exit(0)
   print("Listen on {}:{}".format(local_host, str(local_port)))
   server.listen(5)
 
   while True:
     client_socket, addr = server.accept()
     # 打印连接信息
     print("[==>] Received incoming connection form {}:{}".format(local_host, str(local_port)))
     # 启动线程处理请求
     client_thread = threading.Thread(target=proxy_handler, args=(client_socket, remote_host, remote_port, receive_first))
     client_thread.start()
 
 
 def proxy_handler(client_socket, remote_host, remote_port, receive_first):
   remote_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
   remote_socket.connect((remote_host, remote_port))
 
   # 如果必要，先从远程主机获取数据
   if receive_first:
     remote_buffer = received_from(remote_socket)
     print(hexdump(remote_buffer))
 
     # 发送给响应处理，修改包
     remote_buffer = response_handler(remote_buffer)
     # 如果有数据，发送给本地客户端
     if remote_buffer:
       print("[<==] Sending {} bytes to localhost.".format(str(len(remote_buffer))))
       client_socket.send(remote_buffer)
 
   # 从本地循环读取数据，然后发送给远程主机和本地主机
   while True:
     local_buffer = received_from(client_socket)
     if local_buffer:
       print("[==>] Received {} bytes from localhost.".format(str(len(local_buffer))))
       print(hexdump(local_buffer))  # 这个是修改前的请求
       local_buffer = request_handler(local_buffer)
       print(hexdump(local_buffer))  # 这个是修改后的请求
       remote_socket.send(local_buffer)
       print("[==>] Send to remote.")
 
     remote_buffer = received_from(remote_socket)
     if remote_buffer:
       print("[<==] Received {} bytes from remote.".format(str(len(remote_buffer))))
       print(hexdump(remote_buffer))  # 这个是修改前的请求
       remote_buffer = response_handler(remote_buffer)
       print(hexdump(remote_buffer))  # 这个是修改后的请求
       client_socket.send(remote_buffer)
       print("[<==] Send to localhost.")
 
     # 如果两边都没有数据，关闭连接
     if not local_buffer and remote_buffer:
       client_socket.close()
       remote_socket.close()
       print("[*] No more data.closing connections")
       break
 
 # 数据接收函数，从tcp连接中接收数据。因为有多个地方要从tcp连接中接收数据，所以封装一个函数来处理。
 def received_from(connection):
   buffer = b""
   # 设置10的超时
   connection.settimeout(10)
   try:
     while True:
       data = connection.recv(4096)
       if not data:
         break
       buffer += data
   except:
     pass
   return buffer
 
 
 def hexdump(src):
   # 此处转储流量，比如保存流量到文件
   with open('a.txt', 'a') as f:
     f.write(src.decode('utf-8'))
   return src
 
 
 # 对目标是远程主机的请求进行修改
 def request_handler(buffer):
   # 执行修改
   buffer = buffer.decode('utf-8').replace("GET", "HEAD").encode('utf-8')
   return buffer
 
 
 # 对目标是本地主机的响应进行修改
 def response_handler(buffer):
   # 执行修改
   return buffer
 
 
 if __name__ == '__main__':
   if len(sys.argv[1:]) != 5:
     print("Usage: tcp_proxy.py [local_host] [local_port] [remote_host] [remote_port] [receive_first]")
     print("Example: tcp_proxy.py 127.0.0.1 9999 192.168.1.2 80 True")
     sys.exit(0)
 
   # 设置本地监听参数
   local_host = sys.argv[1]
   local_port = int(sys.argv[2])
 
   # 设置远程目标
   remote_host = sys.argv[3]
   remote_port = int(sys.argv[4])
 
   # 告诉代理在发送给远程主机之前先连接和接受远程数据
   receive_first = sys.argv[5]
   if "true" in receive_first.lower():
     receive_first = True
   else:
     receive_first = False
 
   server_loop(local_host, local_port, remote_host, remote_port, receive_first)
 
```

 

代理就相当于一个中间人的作用，可以记录通信双方的流量，甚至修改双方的流量。将代理部署在受信任的机器上面，还可以将流量“合法化”。还有一个很重要的功能就是借助代理可以访问本不能够访问的一些服务，比如外网访问内网时，正常情况下是不能访问的，借助边缘机器设置代理就可以从外网访问到内网。

### 运行结果

![img](img/a2a2d6f6-437b-11eb-ae31-8cc6814bc10b.png)

客户端成功接收到响应

![img](img/b5d8dde2-437b-11eb-8320-8cc6814bc10b.png)

然后a.txt里面也记录下了请求和响应的流量。包括被修改之前和被修改之后的流量。

![img](img/c74503e4-437b-11eb-b709-8cc6814bc10b.png)